<?php
$text = array("epan" , "cipta" , "akan" , "u" , "asa" , "esok" );

print_r($text);

echo "<br>";
echo "<br>";
echo  "M$text[4] d$text[0]m$text[3] di$text[1]kan oleh apa yang ka$text[3] kerj$text[2] hari ini, b$text[3]kan b$text[5]";



?>