<?php

$lirik ="
    aku ngalah dudu mergo aku wes  ra sayang <br>
    aku mundur dudu mergo tresno ku wes ilang <br>
    nanging aku iki ngerteni <br>
    yen dirimu lebih sayang arek kae <br>
    <br>
    aku mundur alon-alon mergo sadar aku sopo <br>
    mung di goleki pas atimu perih <br>
    aku mundur alin-alon mergo sadar aku sopo <br>
    mung di butuhno pas atimu loro<br>
    <br>
    dek, lungaku ra kaget cidro <br>
    Aku lagi pengen mikir kerjo <br>
    Tak Jaluk kowe ojo <br>
    keloro-loro <br>
    <br>
    dek, tresna ku mung siji kowe <br>
    langit bumi kan dadi saksine <br>
    yen ning ati ra ono<br>
    wanito liyo <br>
    <br>
    kowe rasah sok mutusi.. <br>
    aku ra ning endi-endi <br>
    aku longo <br>
    amung golek rezeki <br>
    
";

$lirik2 = str_replace("a", "o",$lirik);
$lirik3 = str_replace("i", "o" , $lirik2);
$lirik4 = str_replace("u" , "o", $lirik3);
$lirik5 = str_replace("e" , "o", $lirik4);

echo $lirik5;



?>