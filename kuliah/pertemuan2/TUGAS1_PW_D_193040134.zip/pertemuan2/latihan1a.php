<?php

//latihan 1a

$makanan ="Bakso";
$bentuk = "Bulat";

echo $makanan." itu ".$bentuk;
echo ", ";
echo $bentuk." itu ".$makanan;

// echo $makanan." itu ".$bentuk.", ".$bentuk." itu ".$makanan;

?>