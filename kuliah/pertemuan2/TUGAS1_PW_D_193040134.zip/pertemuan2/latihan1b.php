<?php

$angka = 15;
$kali = 5;
$bagi = 3;
$kurang = 30;
$tambah = 10;

echo "Aku adalah angka ".$angka;
echo "<br> Jika aku dikali ".$kali." maka, aku sekarang bernilai ". $angka *= $kali; 
echo "<br> Jika aku dibagi ".$bagi." maka, aku sekarang bernilai ". $angka /= $bagi;
echo "<br> Jika aku dikurang ".$kurang." maka, aku sekarang bernilai ". $angka -= $kurang;
echo "<br> Jika aku ditambah ".$tambah." maka, aku sekarang bernilai ". $angka += $tambah;

?>