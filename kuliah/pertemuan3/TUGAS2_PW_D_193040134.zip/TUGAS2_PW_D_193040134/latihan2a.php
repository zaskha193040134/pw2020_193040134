<?php

$i = 1;
while($i <= 3){
    for($j = 1;  $j<=3; $j++){
        echo "Ini Perulangan ke ($i,$j)<br>";
    }
    $i++;
}


?>